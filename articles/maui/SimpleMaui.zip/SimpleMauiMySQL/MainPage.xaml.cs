﻿using System.Collections.ObjectModel;
using System.Text.Json;

namespace SimpleMauiMySQL;

public partial class MainPage : ContentPage
{
    public ObservableCollection<Product> MenuProducts { get; } = new();
    public ObservableCollection<Product> CartItems { get; } = new();

    public decimal TotalAmount => CartItems.Sum(item => item.price * item.Quantity);
    public string CartContent => GetCartContent();

    public MainPage()
    {
        InitializeComponent();
        BindingContext = this;
        LoadMenu();
    }

    private string GetCartContent()
    {
        if (CartItems.Count == 0) return "Корзина пуста";

        return string.Join("\n", CartItems.Select(item =>
            $"{item.title} - {item.Quantity} шт. × {item.price:C}"));
    }

    private async void LoadMenu()
    {
        try
        {
            MenuProducts.Clear();
            using var client = new HttpClient();
            var json = await client.GetStringAsync("https://restaurant.kolei.ru");
            var items = JsonSerializer.Deserialize<List<Product>>(json);

            foreach (var item in items)
            {
                // Добавляем URL изображения для каждого продукта
                item.ImageUrl = $"https://restaurant.kolei.ru/{item.title.Replace(" ", "%20")}.jpg";
                MenuProducts.Add(item);
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Ошибка", ex.Message, "OK");
        }
    }

    private void AddToCart_Clicked(object sender, EventArgs e)
    {
        if (sender is Button { BindingContext: Product product })
        {
            var existingItem = CartItems.FirstOrDefault(p => p.id == product.id);

            if (existingItem != null)
            {
                existingItem.Quantity++;
            }
            else
            {
                product.Quantity = 1;
                product.InCart = true;
                CartItems.Add(product);
            }

            UpdateCart();
        }
    }

    private void DecreaseProduct_Clicked(object sender, EventArgs e)
    {
        if (sender is Button { BindingContext: Product product })
        {
            var existingItem = CartItems.FirstOrDefault(p => p.id == product.id);

            if (existingItem == null) return;

            if (existingItem.Quantity > 1)
            {
                existingItem.Quantity--;
            }
            else
            {
                existingItem.InCart = false;
                CartItems.Remove(existingItem);
            }

            UpdateCart();
        }
    }

    private void ClearCart_Clicked(object sender, EventArgs e)
    {
        foreach (var item in CartItems)
        {
            item.InCart = false;
            item.Quantity = 0;
        }
        CartItems.Clear();
        UpdateCart();
    }

    private void Checkout_Clicked(object sender, EventArgs e)
    {
        if (CartItems.Count == 0)
        {
            DisplayAlert("Корзина пуста", "Добавьте товары в корзину", "OK");
            return;
        }

        DisplayAlert("Заказ оформлен",
                   $"Спасибо за заказ!\n\nСостав:\n{CartContent}\n\nИтого к оплате: {TotalAmount:C}",
                   "OK");

        ClearCart_Clicked(sender, e);
    }

    private void UpdateCart()
    {
        OnPropertyChanged(nameof(TotalAmount));
        OnPropertyChanged(nameof(CartContent));
    }
}