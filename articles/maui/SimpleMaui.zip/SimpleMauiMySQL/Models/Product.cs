﻿using System.Text.Json.Serialization;

public class Product
{
    public int id { get; set; }
    public string title { get; set; }
    public decimal price { get; set; }
    public string ImageUrl { get; set; }
    public int Quantity { get; set; }
    public bool InCart { get; set; }
}